package org.ThienNguyen.Listener.Passive.Editor.Gui;

import org.ThienNguyen.Listener.Passive.Editor.PassiveDraft;
import org.ThienNguyen.Listener.Passive.Editor.PassiveFileStore;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.List;

/** Menu gốc: danh sách file passive (phân trang) + nút tạo mới. */
public final class PassiveListMenu extends EditorMenu {

    private static final int PAGE_SIZE = 45;
    private int page;

    public PassiveListMenu(Player viewer) {
        super(viewer, null, "&8Passive Editor", 6);
    }

    @Override
    protected void build() {
        List<File> files = PassiveFileStore.listFiles();
        int maxPage = Math.max(0, (files.size() - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, maxPage));

        int from = page * PAGE_SIZE;
        for (int i = 0; i < PAGE_SIZE && from + i < files.size(); i++) {
            File f = files.get(from + i);
            PassiveDraft d = PassiveFileStore.load(f);
            String id = d.getId().isEmpty() ? "&c(thiếu id)" : d.getId();
            set(i, GuiUtil.item(Material.ENCHANTED_BOOK, "&e" + id,
                    "&7Tên: " + GuiUtil.show(d.getDisplayName()),
                    "&7Trigger: &f" + d.getTrigger(),
                    "&7Số action: &f" + d.getActions().size(),
                    "&8File: " + f.getName(),
                    "",
                    "&aClick để chỉnh sửa"),
                    e -> { if (blockedByDraft()) return; new PassiveEditMenu(viewer, this, d).open(); });
        }

        set(45, page > 0 ? GuiUtil.item(Material.ARROW, "&eTrang trước") : GuiUtil.filler(),
                page > 0 ? e -> { page--; refresh(); } : null);
        set(49, GuiUtil.item(Material.EMERALD, "&a+ Tạo passive mới", "&7Nhập ID trong chat."), e -> createNew());
        set(50, GuiUtil.item(Material.PAPER, "&7Trang " + (page + 1) + "/" + (maxPage + 1),
                "&7" + files.size() + " passive"));
        set(53, page < maxPage ? GuiUtil.item(Material.ARROW, "&eTrang sau") : GuiUtil.filler(),
                page < maxPage ? e -> { page++; refresh(); } : null);
        set(48, GuiUtil.item(Material.BARRIER, "&cĐóng"), e -> viewer.closeInventory());

        PassiveEditMenu pending = EditorSessions.pending(viewer.getUniqueId());
        if (pending != null) {
            set(46, GuiUtil.item(Material.WRITABLE_BOOK, "&6Tiếp tục bản nháp",
                    "&7Passive: &f" + GuiUtil.clip(pending.draft().getId(), 30),
                    "&7Có thay đổi chưa lưu.", "",
                    "&aClick: mở lại", "&cShift+Click: bỏ bản nháp"), e -> {
                if (e.isShiftClick()) { EditorSessions.clear(viewer.getUniqueId()); refresh(); }
                else pending.open();
            });
        }
        fillEmpty();
    }

    /** Còn bản nháp chưa lưu -> không cho mở/tạo passive khác (tránh ghi đè mất thay đổi). */
    private boolean blockedByDraft() {
        PassiveEditMenu p = EditorSessions.pending(viewer.getUniqueId());
        if (p == null) return false;
        viewer.sendMessage(GuiUtil.color("&cCòn bản nháp chưa lưu (&f" + p.draft().getId()
                + "&c). Hãy tiếp tục hoặc bỏ nó trước (nút &6Tiếp tục bản nháp&c)."));
        return true;
    }

    private void createNew() {
        if (blockedByDraft()) return;
        ChatPrompt.ask(viewer, "Nhập ID cho passive mới (chữ/số/_/-):",
                s -> {
                    if (!PassiveFileStore.ID_PATTERN.matcher(s).matches()) return "ID không hợp lệ.";
                    if (PassiveFileStore.findById(s, null) != null) return "ID đã tồn tại.";
                    return null;
                },
                id -> {
                    PassiveEditMenu m = new PassiveEditMenu(viewer, this, PassiveDraft.blank(id));
                    m.markDirty(); // passive mới luôn coi là chưa lưu
                    m.open();
                },
                this::open);
    }
}

package org.ThienNguyen.Listener.Passive.Editor.Gui;

import org.ThienNguyen.Listener.Passive.Editor.PassiveDraft;
import org.ThienNguyen.Listener.Passive.Editor.PassiveFileStore;
import org.ThienNguyen.Listener.Passive.Editor.PassiveValidator;
import org.ThienNguyen.Listener.Passive.Trigger.PassiveTrigger;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;

/** Menu chỉnh sửa các thuộc tính cấp cao của một passive. Làm việc trên PassiveDraft, chỉ ghi file khi bấm Lưu. */
public final class PassiveEditMenu extends EditorMenu {

    private final PassiveDraft draft;
    private boolean dirty;

    public PassiveEditMenu(Player viewer, EditorMenu parent, PassiveDraft draft) {
        super(viewer, parent, "&8Passive: " + GuiUtil.clip(draft.getId(), 24), 4);
        this.draft = draft;
    }

    public PassiveDraft draft() { return draft; }

    public void markDirty() { dirty = true; }

    /** Có thay đổi chưa lưu? (EditorSessions dùng để cảnh báo khi đóng bằng ESC). */
    public boolean isDirty() { return dirty; }

    /** Mở menu và ghi nhớ làm bản nháp hiện tại của người chơi. */
    @Override
    public void open() {
        super.open();
        EditorSessions.track(this);
    }

    @Override
    protected void build() {
        boolean isNew = draft.getSourceFile() == null;

        set(10, GuiUtil.item(Material.NAME_TAG, "&eID",
                "&7Hiện tại: " + GuiUtil.show(draft.getId()),
                "", isNew ? "&aClick để đổi" : "&8Không đổi được (đã có file)"),
                isNew ? e -> promptId() : null);

        set(11, GuiUtil.item(Material.OAK_SIGN, "&eTên hiển thị",
                "&7Hiện tại: " + GuiUtil.show(draft.getDisplayName()),
                "&8Hỗ trợ mã màu &", "", "&aClick để đổi"),
                e -> prompt("Nhập tên hiển thị (hỗ trợ &màu):", null, draft::setDisplayName));

        set(12, GuiUtil.item(Material.TRIPWIRE_HOOK, "&eTrigger",
                "&7Hiện tại: &f" + draft.getTrigger(), "",
                "&aChuột trái: kế tiếp", "&aChuột phải: trước đó"),
                e -> { cycleTrigger(e.isRightClick() ? -1 : 1); refresh(); });

        set(13, GuiUtil.item(Material.RABBIT_FOOT, "&eChance (%)",
                "&7Hiện tại: " + GuiUtil.show(draft.getChance()),
                "&8Số 0-100 hoặc biểu thức", "", "&aClick để đổi"),
                e -> prompt("Nhập chance (số hoặc biểu thức, vd 25 hoặc %player_level% * 2):",
                        s -> s.isBlank() ? "Không được trống." : null, draft::setChance));

        set(14, GuiUtil.item(Material.CLOCK, "&eCooldown (giây)",
                "&7Hiện tại: " + GuiUtil.show(draft.getCooldown()), "", "&aClick để đổi"),
                e -> prompt("Nhập cooldown (số nguyên giây >= 0):",
                        s -> s.matches("\\d{1,9}") ? null : "Phải là số nguyên >= 0.", draft::setCooldown));

        set(15, GuiUtil.item(Material.COMPARATOR, "&eĐiều kiện",
                "&7Loại mục tiêu: &f" + draft.getTargetType(),
                "&7Phải chí mạng: &f" + draft.isMustBeCrit(),
                "&7HP mục tiêu dưới: " + GuiUtil.show(draft.getTargetHpPercentBelow()),
                "&7Biểu thức: &f" + draft.getConditionExpressions().size(), "", "&aClick để mở"),
                e -> new ConditionMenu(viewer, this).open());

        set(16, GuiUtil.item(Material.COMMAND_BLOCK, "&eActions",
                "&7Số action: &f" + draft.getActions().size(), "", "&aClick để mở"),
                e -> {
                    ActionTree tree = new ActionTree(this);
                    new ActionListMenu(viewer, this, tree, tree.root(), "&8Actions", null).open();
                });

        set(27, GuiUtil.item(Material.ARROW, dirty ? "&cQuay lại (bỏ thay đổi)" : "&eQuay lại",
                dirty ? List.of("&7Có thay đổi chưa lưu!", "&7Shift+Click để bỏ và quay lại.") : List.of()),
                e -> {
                    if (dirty && !e.isShiftClick()) {
                        viewer.sendMessage(GuiUtil.color("&cCó thay đổi chưa lưu. Bấm Lưu hoặc Shift+Click để bỏ."));
                        return;
                    }
                    EditorSessions.clear(viewer.getUniqueId()); // bỏ bản nháp
                    back();
                });

        set(30, GuiUtil.item(Material.SPYGLASS, "&bKiểm tra lỗi", "&7In kết quả vào chat."), e -> {
            report(PassiveValidator.validate(draft));
            EditorSessions.quietClose(viewer); // đóng để đọc chat, không cần cảnh báo ESC
            viewer.closeInventory();
        });

        set(31, GuiUtil.item(Material.LIME_DYE, dirty ? "&aLưu &c*" : "&aLưu",
                "&7Ghi ra file và reload passive.",
                "&8Giữ comment đầu file & key cấp 1.",
                "&8Comment trong actions sẽ mất.",
                "&8File cũ sao lưu thành .bak."), e -> save());

        set(33, GuiUtil.item(Material.PAPER, "&bNhân bản", "&7Tạo bản sao với ID mới (chưa lưu)."), e ->
                ChatPrompt.ask(viewer, "Nhập ID cho bản sao:", s -> {
                    if (!PassiveFileStore.ID_PATTERN.matcher(s).matches()) return "ID không hợp lệ.";
                    if (PassiveFileStore.findById(s, null) != null) return "ID đã tồn tại.";
                    return null;
                }, id -> {
                    PassiveDraft c = draft.copy();
                    c.setId(id);
                    PassiveEditMenu m = new PassiveEditMenu(viewer, parent, c);
                    m.markDirty();
                    m.open();
                }, this::open));

        if (!isNew) {
            set(34, GuiUtil.item(Material.TNT, "&cXóa passive", "&7File được giữ lại dạng .bak."), e ->
                    new ConfirmMenu(viewer, this, "Xóa passive " + draft.getId() + "?", () -> {
                        String err = PassiveFileStore.delete(draft);
                        if (err == null) EditorSessions.clear(viewer.getUniqueId());
                        viewer.sendMessage(GuiUtil.color(err == null ? "&aĐã xóa passive." : "&c" + err));
                        if (parent != null) parent.open(); else viewer.closeInventory();
                    }).open());
        }

        set(32, GuiUtil.item(Material.MAP, "&bXem YAML", "&7In YAML sẽ ghi ra chat.", "&8(chưa gồm comment)"),
                e -> YamlPreview.send(viewer, "passive " + draft.getId(), draft.raw()));

        fillEmpty();
    }

    private void save() {
        List<PassiveValidator.Issue> issues = PassiveValidator.validate(draft);
        if (PassiveValidator.hasErrors(issues)) {
            report(issues);
            viewer.sendMessage(GuiUtil.color("&cKhông lưu: còn lỗi."));
            EditorSessions.quietClose(viewer);
            viewer.closeInventory();
            return;
        }
        String err = PassiveFileStore.save(draft);
        if (err != null) {
            viewer.sendMessage(GuiUtil.color("&c" + err));
            return;
        }
        dirty = false;
        if (!issues.isEmpty()) report(issues);
        viewer.sendMessage(GuiUtil.color("&aĐã lưu &f" + draft.getSourceFile().getName() + "&a và reload passive."));
        refresh();
    }

    private void report(List<PassiveValidator.Issue> issues) {
        if (issues.isEmpty()) {
            viewer.sendMessage(GuiUtil.color("&aKhông có vấn đề nào."));
            return;
        }
        for (PassiveValidator.Issue i : issues) viewer.sendMessage(i.toString());
    }

    private void cycleTrigger(int dir) {
        PassiveTrigger[] all = PassiveTrigger.values();
        int idx = 0;
        for (int i = 0; i < all.length; i++) if (all[i].name().equalsIgnoreCase(draft.getTrigger())) idx = i;
        draft.setTrigger(all[Math.floorMod(idx + dir, all.length)]);
        dirty = true;
    }

    private void promptId() {
        prompt("Nhập ID mới (chữ/số/_/-):", s -> {
            if (!PassiveFileStore.ID_PATTERN.matcher(s).matches()) return "ID không hợp lệ.";
            if (PassiveFileStore.findById(s, null) != null) return "ID đã tồn tại.";
            return null;
        }, draft::setId);
    }

    /** Hỏi chat -> áp giá trị vào draft -> đánh dấu dirty -> mở lại menu. */
    private void prompt(String hint, java.util.function.Function<String, String> validator,
                        java.util.function.Consumer<String> apply) {
        ChatPrompt.ask(viewer, hint, validator, v -> { apply.accept(v); dirty = true; open(); }, this::open);
    }
}

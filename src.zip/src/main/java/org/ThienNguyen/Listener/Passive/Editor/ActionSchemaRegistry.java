package org.ThienNguyen.Listener.Passive.Editor;

import org.ThienNguyen.Listener.Passive.Editor.ActionSchema.Category;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.ThienNguyen.Listener.Passive.Editor.FieldKind.*;

/**
 * Registry schema cho toàn bộ 31 action của passive (khớp MechanicRegistry).
 * <ul>
 *   <li>Sát thương / hỗ trợ / di chuyển / thế giới / hiển thị: DAMAGE, EFFECT, BUFF_STAT, HEAL, FLAME, LAUNCH, EXPLODE,
 *       SUMMON_TNT, DROP_ITEM, COMMAND, MESSAGE, SOUND, PARTICLE_ANIMATION, PARTICLE_PROJECTILE, BREAK_AREA.</li>
 *   <li>Container / biến / đếm: DELAY, REPEAT, HIT_COUNTER, STACK_COUNTER, ADD_VALUE, CHECK_VALUE, TARGET_FILTER, REVIVE.</li>
 *   <li>Triệu hồi / trạng thái / tích hợp: SUMMON_VANILLA, SUMMON_MM, TITLE, STATUS, MYTHIC_SKILL, LIGHTNING.</li>
 *   <li>Đạn / vùng thuốc: PROJECTILE_SHOT, POTION_ZONE (đọc từ source mechanic).</li>
 * </ul>
 */
public final class ActionSchemaRegistry {

    private static final Map<String, ActionSchema> SCHEMAS = new LinkedHashMap<>();

    /** Danh sách stat hợp lệ của BUFF_STAT. */
    private static final String[] STATS = {
            "damage", "pve_damage", "pvp_damage", "all_damage", "bow_damage", "magic_damage", "true_damage",
            "death_damage", "critical_chance", "critical_damage", "critical_damage_reduction", "lifesteal",
            "penetration", "armor_pen", "accuracy", "damage_reduction", "armor", "pve_defense", "pvp_defense",
            "all_defense", "magic_defense", "dodge_rate", "block_rate", "thorns", "knockback_resistance",
            "max_mana", "mana_regen", "health_regen", "exp_bonus", "movement_speed", "health"
    };

    private ActionSchemaRegistry() {
    }

    // ------------------------------------------------------------------ API

    /** @return schema của type (không phân biệt hoa/thường) hoặc null nếu chưa có. */
    public static ActionSchema get(String type) {
        return type == null ? null : SCHEMAS.get(type.toUpperCase(Locale.ROOT));
    }

    public static boolean has(String type) {
        return get(type) != null;
    }

    public static Collection<ActionSchema> all() {
        return Collections.unmodifiableCollection(SCHEMAS.values());
    }

    public static List<ActionSchema> byCategory(Category category) {
        List<ActionSchema> out = new ArrayList<>();
        for (ActionSchema s : SCHEMAS.values()) {
            if (s.category() == category) out.add(s);
        }
        return out;
    }

    // ------------------------------------------------------------- factories

    private static FieldDef target(String def, String... allowed) {
        return FieldDef.of("target", ENUM, def, "Mục tiêu", "Thực thể chịu tác động của hành động.")
                .withAllowed(allowed).withIcon(Material.ENDER_EYE);
    }

    private static FieldDef expr(String key, String def, String nameVN, String descVN) {
        return FieldDef.of(key, EXPRESSION, def, nameVN, descVN);
    }

    private static FieldDef dbl(String key, double def, String nameVN, String descVN) {
        return FieldDef.of(key, DOUBLE, def, nameVN, descVN);
    }

    private static FieldDef integer(String key, int def, String nameVN, String descVN) {
        return FieldDef.of(key, INT, def, nameVN, descVN).withRange(1.0, null);
    }

    private static FieldDef bool(String key, boolean def, String nameVN, String descVN) {
        return FieldDef.of(key, BOOLEAN, def, nameVN, descVN);
    }

    private static FieldDef enumOf(String key, String def, String nameVN, String descVN, String... allowed) {
        return FieldDef.of(key, ENUM, def, nameVN, descVN).withAllowed(allowed);
    }

    private static FieldDef damageType(String def) {
        return enumOf("damage-type", def, "Loại sát thương",
                "NORMAL = bị giáp giảm, TRUE = sát thương chuẩn.", "NORMAL", "TRUE")
                .withIcon(Material.IRON_CHESTPLATE);
    }

    private static FieldDef children(String key, String nameVN, String descVN) {
        return FieldDef.of(key, ACTION_LIST, null, nameVN, descVN);
    }

    private static void register(ActionSchema s) {
        SCHEMAS.put(s.type(), s);
    }

    // ---------------------------------------------------------------- schemas

    static {
        register(new ActionSchema("DAMAGE", Category.DAMAGE, Material.IRON_SWORD,
                "Gây Sát Thương", "Gây một lượng sát thương lên mục tiêu.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        expr("amount", "0", "Lượng sát thương", "Lượng sát thương gây ra (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        damageType("TRUE"))));

        register(new ActionSchema("EFFECT", Category.SUPPORT, Material.POTION,
                "Hiệu Ứng Thuốc", "Gán hiệu ứng thuốc vanilla lên mục tiêu.",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        FieldDef.of("effect", POTION_EFFECT, null, "Loại hiệu ứng",
                                "Tên PotionEffectType (SPEED, POISON, REGENERATION...).").asRequired(),
                        expr("seconds", "5", "Thời gian (giây)", "Thời gian hiệu ứng tồn tại (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        expr("level", "1", "Cấp độ", "Cấp hiệu ứng, 1 = cấp I (hỗ trợ biểu thức).")
                                .withIcon(Material.EXPERIENCE_BOTTLE),
                        bool("ambient", false, "Dạng beacon", "Hạt hiệu ứng mờ kiểu beacon."),
                        bool("particles", true, "Hiện hạt", "false = ẩn hạt của hiệu ứng thuốc."))));

        register(new ActionSchema("BUFF_STAT", Category.SUPPORT, Material.NETHER_STAR,
                "Buff Chỉ Số", "Tăng/giảm tạm thời một chỉ số nội bộ của plugin (chỉ người chơi).",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        enumOf("stat", null, "Chỉ số", "Chỉ số nội bộ được buff.", STATS).asRequired()
                                .withIcon(Material.ENCHANTED_BOOK),
                        expr("amount", "0", "Lượng buff", "Lượng cộng thêm, số âm = nerf (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        expr("duration-seconds", "5", "Thời gian (giây)", "Số giây trước khi buff bị gỡ (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK))));

        register(new ActionSchema("HEAL", Category.SUPPORT, Material.GOLDEN_APPLE,
                "Hồi Máu", "Hồi máu cố định hoặc theo % máu tối đa.",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        expr("amount", "0", "Lượng hồi", "Lượng máu hồi cố định (hỗ trợ biểu thức).")
                                .withIcon(Material.APPLE),
                        expr("percent", "0", "Hồi theo %", "% máu tối đa, ưu tiên hơn 'amount' nếu > 0 (hỗ trợ biểu thức).")
                                .withIcon(Material.GLISTERING_MELON_SLICE))));

        register(new ActionSchema("FLAME", Category.DAMAGE, Material.BLAZE_POWDER,
                "Thiêu Đốt", "Đốt mục tiêu, gây sát thương mỗi giây khi đang cháy.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        expr("damage-per-second", "0", "Sát thương/giây", "Sát thương mỗi giây khi cháy (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        expr("duration-seconds", "5", "Thời gian (giây)", "Thời gian cháy (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        bool("visual-fire", true, "Hiện lửa", "false = ẩn ngọn lửa nhưng vẫn gây sát thương."))));

        register(new ActionSchema("LAUNCH", Category.MOVEMENT, Material.FEATHER,
                "Hất Tung", "Đẩy thực thể theo hướng nhìn của thực thể tham chiếu.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        enumOf("reference", "SELF", "Thực thể tham chiếu", "Thực thể dùng để tính hướng đẩy.",
                                "SELF", "VICTIM").withIcon(Material.SPYGLASS),
                        expr("forward", "0", "Lực tiến", "Lực về phía trước, số âm = đẩy lùi (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW),
                        expr("side", "0", "Lực ngang", "Lực theo chiều ngang (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW),
                        expr("up", "0", "Lực lên", "Lực hất lên trên (hỗ trợ biểu thức).")
                                .withIcon(Material.FIREWORK_ROCKET),
                        bool("reset-velocity", true, "Ghi đè vận tốc", "false = cộng dồn vào vận tốc hiện tại."))));

        register(new ActionSchema("EXPLODE", Category.DAMAGE, Material.TNT,
                "Phát Nổ", "Tạo vụ nổ gây sát thương các thực thể xung quanh.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM", "BLOCK"),
                        expr("power", "4.0", "Sức nổ", "Sức nổ vanilla (đẩy lùi/âm thanh), hỗ trợ biểu thức.")
                                .withIcon(Material.FIRE_CHARGE),
                        expr("radius", "4.0", "Bán kính", "Bán kính tìm thực thể chịu sát thương (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPASS),
                        expr("amount", "0", "Sát thương", "Sát thương lên mỗi thực thể trúng (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        damageType("TRUE"),
                        bool("include-self", false, "Gồm bản thân", "true = chủ passive cũng nhận sát thương."),
                        bool("break-blocks", false, "Phá block", "true = vụ nổ phá block (tôn trọng WorldGuard)."),
                        dbl("particle-scale", 1.0, "Cỡ hạt nổ", "Hệ số nhân kích thước/độ lan của hạt nổ."))));

        register(new ActionSchema("SUMMON_TNT", Category.DAMAGE, Material.TNT_MINECART,
                "Triệu Hồi TNT", "Tạo một hoặc nhiều TNT đã châm ngòi tại vị trí mục tiêu.",
                List.of(
                        target("VICTIM", "SELF", "ACTOR", "VICTIM", "BLOCK"),
                        enumOf("mode", "FIXED", "Chế độ", "FALL = rơi từ trên, SHOOT = bắn ngẫu nhiên, FIXED = xuất hiện tại chỗ.",
                                "FALL", "SHOOT", "FIXED").withIcon(Material.REPEATER),
                        expr("amount", "1", "Số lượng", "Số TNT được tạo (hỗ trợ biểu thức).")
                                .withIcon(Material.CHEST),
                        expr("power", "4.0", "Sức nổ", "Sức nổ, chỉ dùng khi 'destroy-blocks' = true (hỗ trợ biểu thức).")
                                .withIcon(Material.FIRE_CHARGE)
                                .visibleIf("destroy-blocks", "true"),
                        expr("fuse-ticks", "80", "Ngòi (tick)", "Số tick trước khi nổ, 80 = 4 giây (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        bool("destroy-blocks", false, "Phá block", "true = vụ nổ phá block; false = chỉ ảnh hưởng thực thể."),
                        expr("fall-height", "10.0", "Độ cao rơi", "(FALL) Số block phía trên điểm gốc nơi TNT xuất hiện (hỗ trợ biểu thức).")
                                .withIcon(Material.ANVIL)
                                .visibleIf("mode", "FALL"),
                        expr("shoot-speed", "1.0", "Tốc độ bắn", "(SHOOT) Tốc độ phóng TNT (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW)
                                .visibleIf("mode", "SHOOT"),
                        expr("shoot-spread-angle", "45.0", "Góc tỏa tối đa", "(SHOOT) Góc phóng lên tối đa (độ), ngẫu nhiên cho mỗi TNT (hỗ trợ biểu thức).")
                                .withIcon(Material.BOW)
                                .visibleIf("mode", "SHOOT"),
                        dbl("radius", 1.0, "Bán kính rải", "(FIXED) Bán kính rải TNT khi số lượng > 1.")
                                .withIcon(Material.COMPASS)
                                .visibleIf("mode", "FIXED"),
                        expr("damage", "6.0", "Sát thương", "Sát thương gây ra khi TNT phát nổ (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        expr("damage-radius", "4.0", "Bán kính sát thương", "Bán kính quanh TNT để tìm mục tiêu (hỗ trợ biểu thức).")
                                .withIcon(Material.SPYGLASS),
                        damageType("TRUE"),
                        bool("include-self", false, "Gồm bản thân", "Cho phép chủ passive bị TNT gây sát thương."),
                        dbl("particle-scale", 1.5, "Cỡ hạt nổ", "Kích thước hạt của vụ nổ."))));

        register(new ActionSchema("DROP_ITEM", Category.WORLD, Material.GOLD_NUGGET,
                "Rơi Vật Phẩm", "Làm rơi vật phẩm tại vị trí mục tiêu.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        FieldDef.of("material", MATERIAL, "GOLD_NUGGET", "Vật phẩm", "Tên Material của vật phẩm rơi ra."),
                        expr("amount", "1", "Số lượng", "Số lượng, hỗ trợ khoảng (\"1-3\"), biểu thức và PAPI.")
                                .withIcon(Material.CHEST))));

        register(new ActionSchema("COMMAND", Category.UTILITY, Material.COMMAND_BLOCK,
                "Chạy Lệnh", "Chạy một lệnh tùy ý (give vật phẩm, kinh tế, plugin khác...).",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        enumOf("mode", "OP", "Chế độ chạy", "OP = console chạy đủ quyền, PLAYER = mục tiêu tự chạy lệnh.",
                                "OP", "PLAYER").withIcon(Material.REPEATER),
                        FieldDef.of("command", STRING, null, "Lệnh",
                                "Lệnh cần chạy, không có dấu '/'. Dùng {player}, {actor}, {damage}.")
                                .asRequired())));

        register(new ActionSchema("MESSAGE", Category.UTILITY, Material.PAPER,
                "Gửi Tin Nhắn", "Gửi tin nhắn riêng cho người chơi (hỗ trợ mã màu &).",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        FieldDef.of("message", STRING, null, "Nội dung",
                                "Nội dung chat, hỗ trợ &-màu và {actor_name}, {victim_name}, {damage}.")
                                .asRequired())));

        register(new ActionSchema("SOUND", Category.VISUAL, Material.NOTE_BLOCK,
                "Phát Âm Thanh", "Phát một âm thanh tại vị trí mục tiêu.",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        FieldDef.of("sound", SOUND, null, "Âm thanh", "Tên Sound của Bukkit.").asRequired(),
                        dbl("volume", 1.0, "Âm lượng", "Âm lượng phát ra.").withRange(0.0, null),
                        dbl("pitch", 1.0, "Cao độ", "Cao độ âm thanh, từ 0.5 đến 2.0.").withRange(0.5, 2.0))));

        register(new ActionSchema("PARTICLE_ANIMATION", Category.VISUAL, Material.FIREWORK_STAR,
                "Hoạt Ảnh Hạt", "Hiệu ứng hạt hình tròn/cầu quay quanh mục tiêu theo thời gian.",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        FieldDef.of("particle", PARTICLE, "FLAME", "Loại hạt", "Loại hạt Bukkit dùng cho hiệu ứng."),
                        enumOf("shape", "CIRCLE", "Hình dạng", "CIRCLE = vòng phẳng, SPHERE = hình cầu 3D.",
                                "CIRCLE", "SPHERE").withIcon(Material.HEART_OF_THE_SEA),
                        expr("radius", "1.0", "Bán kính", "Bán kính hiệu ứng (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPASS),
                        expr("height", "1.0", "Độ cao", "Độ lệch trục Y tính từ chân mục tiêu (hỗ trợ biểu thức).")
                                .withIcon(Material.LADDER),
                        expr("forward-offset", "0.0", "Lệch trước/sau", "Dịch tâm ra trước (+) hoặc ra sau (-) theo hướng nhìn (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW),
                        expr("side-offset", "0.0", "Lệch trái/phải", "Dịch tâm sang phải (+) hoặc trái (-) theo hướng nhìn (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW),
                        expr("points-per-tick", "12", "Điểm mỗi tick", "Số điểm vẽ mỗi tick (hỗ trợ biểu thức).")
                                .withIcon(Material.GLOWSTONE_DUST),
                        expr("particle-per-point", "1", "Hạt mỗi điểm", "Số hạt tại mỗi điểm (hỗ trợ biểu thức).")
                                .withIcon(Material.GLOWSTONE_DUST),
                        expr("duration-seconds", "3", "Thời gian (giây)", "Thời gian hiệu ứng kéo dài (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        integer("update-interval-ticks", 4, "Chu kỳ cập nhật (tick)", "Càng thấp càng mượt nhưng càng tốn tài nguyên.")
                                .withIcon(Material.REPEATER),
                        bool("rotate", true, "Xoay", "false = hiệu ứng đứng yên."),
                        FieldDef.of("dust-color", STRING, "#FF5500", "Màu bụi", "Mã màu hex (#RRGGBB), dùng khi hạt là DUST.")
                                .withIcon(Material.RED_DYE)
                                .visibleIf("particle", "DUST"),
                        FieldDef.of("block-material", MATERIAL, "OAK_LEAVES", "Block hạt", "Dùng khi hạt là BLOCK hoặc FALLING_DUST.")
                                .visibleIf("particle", "BLOCK", "FALLING_DUST"))));

        register(new ActionSchema("PARTICLE_PROJECTILE", Category.DAMAGE, Material.FIRE_CHARGE,
                "Đạn Hạt", "Bắn đạn hạt về phía nạn nhân, trúng thì gây sát thương và tạo hiệu ứng nổ.",
                List.of(
                        FieldDef.of("particle", PARTICLE, "FLAME", "Loại hạt", "Loại hạt bay dọc đường đạn."),
                        expr("particle-per-step", "1", "Hạt mỗi bước", "Số hạt mỗi bước bay (hỗ trợ biểu thức).")
                                .withIcon(Material.GLOWSTONE_DUST),
                        expr("speed", "1.0", "Tốc độ", "Tốc độ bay, block/tick (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW),
                        expr("amount", "0", "Sát thương", "Sát thương khi trúng (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        damageType("NORMAL"),
                        expr("hit-radius", "1.0", "Bán kính va chạm", "Bán kính hitbox của đạn (hỗ trợ biểu thức).")
                                .withIcon(Material.SPYGLASS),
                        bool("hit-actor-self", false, "Trúng người bắn", "true = đạn có thể trúng chính người bắn."),
                        bool("immediate-impact", false, "Nổ ngay", "true = bỏ qua bay, tác động ngay tại vị trí."),
                        FieldDef.of("dust-color", STRING, "#FFAA00", "Màu bụi", "Mã màu hex (#RRGGBB), dùng cho hạt DUST.")
                                .withIcon(Material.RED_DYE)
                                .visibleIf("particle", "DUST"),
                        FieldDef.of("block-material", MATERIAL, "MAGMA_BLOCK", "Block hạt", "Dùng cho hạt BLOCK/FALLING_DUST.")
                                .visibleIf("particle", "BLOCK", "FALLING_DUST"),

                        enumOf("flight-shape", "NONE", "Hình dạng đường bay", "NONE hoặc TORNADO (xoắn ốc quanh đạn).",
                                "NONE", "TORNADO").withIcon(Material.HEART_OF_THE_SEA),
                        expr("flight-radius", "0.45", "Bán kính xoắn", "Bán kính vòng xoáy khi bay (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPASS)
                                .visibleIf("flight-shape", "TORNADO"),
                        expr("flight-rotation-speed", "0.55", "Tốc độ xoay", "Tốc độ xoay của vòng xoáy (hỗ trợ biểu thức).")
                                .withIcon(Material.REPEATER)
                                .visibleIf("flight-shape", "TORNADO"),
                        integer("flight-rings", 2, "Số vòng", "Số vòng xoáy (TORNADO).")
                                .visibleIf("flight-shape", "TORNADO"),
                        integer("flight-points-per-ring", 6, "Điểm mỗi vòng", "Số điểm trên mỗi vòng xoáy.")
                                .visibleIf("flight-shape", "TORNADO"),
                        bool("flight-grow", true, "Phình to dần", "Hiệu ứng có lớn dần theo thời gian không.")
                                .visibleIf("flight-shape", "TORNADO"),
                        expr("flight-grow-steps", "20", "Số bước phình", "Số bước để đạt kích thước tối đa (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK)
                                .visibleIf("flight-shape", "TORNADO"),
                        bool("sweep-attack", false, "Hiệu ứng quét", "Bật hiệu ứng SWEEP_ATTACK dọc đường bay."),
                        integer("sweep-attack-interval", 4, "Chu kỳ quét (tick)", "Số tick giữa mỗi lần tạo hiệu ứng quét.")
                                .withIcon(Material.REPEATER)
                                .visibleIf("sweep-attack", "true"),

                        enumOf("impact-shape", "NONE", "Hình dạng va chạm", "Hình ảnh khi trúng: NONE, CIRCLE, SPHERE, BURST, TORNADO.",
                                "NONE", "CIRCLE", "SPHERE", "BURST", "TORNADO").withIcon(Material.HEART_OF_THE_SEA),
                        FieldDef.of("impact-particle", PARTICLE, null, "Hạt va chạm", "Loại hạt của hiệu ứng khi trúng.")
                                .withIcon(Material.BLAZE_POWDER),
                        expr("impact-radius", "3.0", "Bán kính va chạm", "Bán kính vùng sát thương khi trúng, luôn là hình cầu (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPASS),
                        expr("impact-duration-ticks", "15", "Thời gian va chạm (tick)", "Thời gian hiệu ứng va chạm kéo dài (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        expr("impact-damage", null, "Sát thương va chạm", "Sát thương mỗi tick va chạm, mặc định bằng 'amount' (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE))));

        register(new ActionSchema("BREAK_AREA", Category.WORLD, Material.DIAMOND_PICKAXE,
                "Đào Vùng", "Đào thêm các block quanh block vừa phá (chỉ dùng với ON_BLOCK_BREAK).",
                List.of(
                        expr("size", "3", "Kích thước", "Độ dài cạnh vùng đào, 3 = 3x3, nên dùng số lẻ (hỗ trợ biểu thức).")
                                .withIcon(Material.IRON_PICKAXE),
                        expr("depth", "1", "Độ sâu", "Số block đào thêm theo trục Y (hỗ trợ biểu thức).")
                                .withIcon(Material.LADDER),
                        bool("use-tool-drops", true, "Drop theo công cụ", "true = drop theo Fortune/Silk Touch; false = drop mặc định."),
                        FieldDef.of("excluded-materials", STRING, "BEDROCK,BARRIER,...", "Block loại trừ",
                                "Danh sách block không bị đào, ngăn cách bằng dấu phẩy.")
                                .withIcon(Material.BEDROCK))));

        // ================================================================ phần 2 ================================================================


        // ---- Container / luồng điều khiển ----

        register(new ActionSchema("DELAY", Category.UTILITY, Material.CLOCK,
                "Trì Hoãn", "Chờ N giây rồi chạy danh sách hành động con.",
                List.of(
                        expr("seconds", "1", "Thời gian chờ (giây)", "Số giây chờ trước khi chạy hành động con (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        children("children", "Hành động con", "Danh sách hành động chạy sau khi chờ xong."))));

        register(new ActionSchema("REPEAT", Category.UTILITY, Material.REPEATER,
                "Lặp Lại", "Lặp cả danh sách hành động con nhiều lần, cách nhau một khoảng thời gian.",
                List.of(
                        expr("times", "1", "Số lần lặp", "Tổng số lần lặp (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPARATOR),
                        expr("interval-seconds", "1", "Khoảng cách (giây)", "Thời gian giữa hai lần lặp (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        children("children", "Hành động con", "Danh sách hành động được lặp lại."))));

        register(new ActionSchema("HIT_COUNTER", Category.UTILITY, Material.COMPARATOR,
                "Đếm Đòn Đánh", "Đếm số lần kích hoạt, đủ ngưỡng mới chạy hành động con.",
                List.of(
                        expr("every", "5", "Ngưỡng kích hoạt", "Số lần kích hoạt cần có để chạy hành động con (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPARATOR),
                        expr("reset-after", null, "Reset sau", "Số lần tối đa trước khi bộ đếm tự reset, mặc định bằng 'every' (hỗ trợ biểu thức).")
                                .withIcon(Material.BARRIER),
                        children("children", "Hành động con", "Danh sách hành động chạy khi đạt ngưỡng."))));

        register(new ActionSchema("STACK_COUNTER", Category.UTILITY, Material.NETHER_STAR,
                "Cộng Dồn Stack", "Cộng dồn stack theo người chơi, tới mốc nhất định thì chạy hành động tương ứng.",
                List.of(
                        expr("max-stacks", "5", "Stack tối đa", "Số stack tối đa (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.NETHER_STAR),
                        expr("decay-seconds", "5", "Thời gian tan (giây)", "Số giây rảnh trước khi stack về 0 (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        bool("trigger-at-max", false, "Kích hoạt ở mức tối đa",
                                "true = chạm tối đa sẽ chạy lại mốc cuối (gia hạn); false = stack về 0."),
                        bool("on-quit", true, "Reset khi thoát", "true = reset stack về 0 khi người chơi thoát game."),
                        bool("on-death", true, "Reset khi chết", "true = reset stack về 0 khi người chơi chết."),
                        children("on-empty", "Khi stack về 0", "Danh sách hành động chạy khi stack tan về 0."),
                        // TODO: milestones là Map<String, List<Map>> (khóa là số stack), không phải một danh sách.
                        // Hiện FieldKind chưa có kind cho map nên tạm dùng ACTION_LIST; GUI phải xử lý riêng key "milestones".
                        children("milestones", "Các mốc stack", "Bảng 'số stack' → danh sách hành động chạy khi đạt đúng mốc đó."))));

        register(new ActionSchema("ADD_VALUE", Category.UTILITY, Material.EXPERIENCE_BOTTLE,
                "Cộng Giá Trị", "Cộng một số vào giá trị có khóa lưu trên mục tiêu (dùng với CHECK_VALUE).",
                List.of(
                        target("VICTIM", "SELF", "ACTOR", "VICTIM"),
                        FieldDef.of("key", STRING, null, "Khóa", "Định danh giá trị lưu, dùng chung giữa các passive trên cùng thực thể.")
                                .asRequired().withIcon(Material.NAME_TAG),
                        expr("amount", "1", "Lượng cộng", "Lượng cộng thêm, số âm = trừ (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        expr("duration", "0", "Thời hạn (giây)", "Số giây trước khi giá trị hết hạn, 0 = không hết hạn (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK))));

        register(new ActionSchema("CHECK_VALUE", Category.UTILITY, Material.SPYGLASS,
                "Kiểm Tra Giá Trị", "So sánh giá trị đã lưu với ngưỡng, đạt thì chạy hành động con.",
                List.of(
                        target("VICTIM", "SELF", "ACTOR", "VICTIM"),
                        FieldDef.of("key", STRING, null, "Khóa", "Định danh giá trị cần đọc (phải khớp với ADD_VALUE).")
                                .asRequired().withIcon(Material.NAME_TAG),
                        FieldDef.of("operator", ENUM, ">=", "Phép so sánh", "Phép so sánh giá trị đã lưu với ngưỡng.")
                                .withAllowed(">=", ">", "<=", "<", "==", "!=").withIcon(Material.COMPARATOR),
                        expr("value", "1", "Ngưỡng", "Giá trị ngưỡng để so sánh (hỗ trợ biểu thức).")
                                .withIcon(Material.GOLD_NUGGET),
                        bool("consume", false, "Tiêu hao", "true = xóa giá trị đã lưu khi kiểm tra đạt."),
                        children("actions", "Hành động con", "Danh sách hành động chạy khi so sánh đạt."))));

        register(new ActionSchema("TARGET_FILTER", Category.UTILITY, Material.HOPPER,
                "Lọc Mục Tiêu", "Chỉ chạy hành động con khi mục tiêu thuộc loại cho phép.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        FieldDef.of("types", STRING_LIST, null, "Loại cho phép",
                                "PLAYER, ALL, ALL_MM, MM_<ID> hoặc tên EntityType (vd ZOMBIE).")
                                .asRequired().withIcon(Material.BOOK),
                        children("actions", "Hành động con", "Danh sách hành động chạy khi mục tiêu khớp.").asRequired())));

        register(new ActionSchema("REVIVE", Category.SUPPORT, Material.TOTEM_OF_UNDYING,
                "Hồi Sinh", "Chặn đòn chí mạng, cứu người chơi rồi chạy chuỗi hành động con.",
                List.of(
                        target("SELF", "SELF", "VICTIM"),
                        expr("duration-seconds", "10", "Thời gian bảo vệ (giây)", "Thời gian bảo vệ tồn tại, 0 hoặc bỏ trống = vĩnh viễn tới khi kích hoạt (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.CLOCK),
                        expr("revive-health-percent", "50", "% máu hồi sinh", "% máu tối đa hồi ngay khi được cứu, 0 hoặc bỏ trống = giữ nguyên (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.GOLDEN_APPLE),
                        children("actions", "Hành động con", "Danh sách hành động chạy ngay khi người chơi được hồi sinh."))));

        // ---- Triệu hồi ----

        register(new ActionSchema("SUMMON_VANILLA", Category.WORLD, Material.ZOMBIE_SPAWN_EGG,
                "Triệu Hồi Mob Vanilla", "Triệu hồi một thực thể vanilla tại vị trí mục tiêu.",
                List.of(
                        // Chưa có FieldKind.ENTITY_TYPE nên dùng STRING (tên EntityType).
                        FieldDef.of("mob", STRING, null, "Loại mob", "Tên EntityType (vd ZOMBIE, SKELETON).")
                                .asRequired().withIcon(Material.ZOMBIE_HEAD),
                        expr("health", null, "Máu", "Máu của mob, mặc định theo loại thực thể (hỗ trợ biểu thức).")
                                .withIcon(Material.RED_DYE),
                        expr("damage", null, "Sát thương", "Sát thương tấn công, mặc định theo loại thực thể (hỗ trợ biểu thức).")
                                .withIcon(Material.IRON_SWORD),
                        FieldDef.of("speed", DOUBLE, 1.0, "Tốc độ", "Hệ số nhân tốc độ di chuyển.")
                                .withIcon(Material.FEATHER),
                        target("VICTIM", "SELF", "VICTIM"),
                        children("on-death", "Khi mob chết", "Danh sách hành động chạy khi mob được triệu hồi chết."))));

        register(new ActionSchema("SUMMON_MM", Category.WORLD, Material.DRAGON_EGG,
                "Triệu Hồi Mob MythicMobs", "Triệu hồi mob MythicMobs, có thể ghi đè cấp/chỉ số (cần MythicMobs).",
                List.of(
                        FieldDef.of("mob", STRING, null, "ID mob", "ID MythicMob, phân biệt hoa/thường.")
                                .asRequired().withIcon(Material.DRAGON_HEAD),
                        expr("level", "1", "Cấp độ", "Cấp độ mob (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.EXPERIENCE_BOTTLE),
                        expr("health", null, "Máu", "Ghi đè máu tối đa, mặc định theo mob (hỗ trợ biểu thức).")
                                .withIcon(Material.RED_DYE),
                        expr("damage", null, "Sát thương", "Ghi đè sát thương, mặc định theo mob (hỗ trợ biểu thức).")
                                .withIcon(Material.IRON_SWORD),
                        FieldDef.of("speed", DOUBLE, 1.0, "Tốc độ", "Hệ số nhân tốc độ (2 = 200%).")
                                .withIcon(Material.FEATHER),
                        target("VICTIM", "SELF", "VICTIM"),
                        children("on-death", "Khi mob chết", "Danh sách hành động chạy khi mob được triệu hồi chết."))));

        // ---- Hiển thị / trạng thái / tích hợp ----

        register(new ActionSchema("TITLE", Category.VISUAL, Material.OAK_SIGN,
                "Hiện Tiêu Đề", "Gửi Title/Subtitle cho người chơi (để trống phần nào thì ẩn phần đó).",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        FieldDef.of("title", STRING, null, "Tiêu đề", "Nội dung tiêu đề chính, hỗ trợ PAPI của người nhận.")
                                .withIcon(Material.NAME_TAG),
                        FieldDef.of("subtitle", STRING, null, "Phụ đề", "Nội dung phụ đề, hỗ trợ PAPI của người nhận.")
                                .withIcon(Material.PAPER),
                        expr("fade-in", "10", "Hiện dần (tick)", "Số tick hiện dần, tính theo chủ passive (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        expr("stay", "70", "Giữ nguyên (tick)", "Số tick giữ nguyên, tính theo chủ passive (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        expr("fade-out", "20", "Mờ dần (tick)", "Số tick mờ dần, tính theo chủ passive (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK))));

        register(new ActionSchema("STATUS", Category.SUPPORT, Material.SHIELD,
                "Trạng Thái Đặc Biệt", "Áp trạng thái tạm thời: choáng, trói chân, tước vũ khí hoặc bất tử.",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        FieldDef.of("status", ENUM, null, "Trạng thái", "STUN, ROOT, DISARM hoặc INVINCIBLE.")
                                .withAllowed("STUN", "ROOT", "DISARM", "INVINCIBLE").asRequired()
                                .withIcon(Material.SHIELD),
                        expr("duration", "3", "Thời gian (giây)", "Thời gian trạng thái kéo dài (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.CLOCK))));

        register(new ActionSchema("MYTHIC_SKILL", Category.DAMAGE, Material.BLAZE_ROD,
                "Kỹ Năng MythicMobs", "Tung một skill MythicMobs khi passive kích hoạt (cần MythicMobs).",
                List.of(
                        target("VICTIM", "SELF", "VICTIM"),
                        FieldDef.of("skill", STRING, null, "Tên skill", "Tên skill khớp với ID trong MythicMobs/Skills/.")
                                .asRequired().withIcon(Material.ENCHANTED_BOOK),
                        expr("damage-multiplier", "1.0", "Hệ số sát thương", "Hệ số truyền qua 'power' của skill, chỉ có tác dụng nếu skill bật power (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.REDSTONE))));

        register(new ActionSchema("LIGHTNING", Category.DAMAGE, Material.LIGHTNING_ROD,
                "Sét Đánh", "Giáng sét lên mục tiêu, có thể kèm sát thương, thiêu đốt hoặc chỉ hiệu ứng.",
                List.of(
                        target("VICTIM", "ACTOR", "VICTIM"),
                        expr("damage", "0.0", "Sát thương thêm", "Sát thương thêm lên mục tiêu (hỗ trợ biểu thức/PAPI).")
                                .withIcon(Material.REDSTONE),
                        bool("causes-burning", false, "Gây cháy", "true = cú sét làm mục tiêu bốc cháy."),
                        FieldDef.of("fire-ticks", INT, 100, "Thời gian cháy (tick)", "Thời gian cháy nếu 'causes-burning' = true (100 tick = 5 giây).")
                                .withRange(0.0, null).withIcon(Material.FLINT_AND_STEEL)
                                .visibleIf("causes-burning", "true"),
                        bool("visual-only", false, "Chỉ hiệu ứng", "true = chỉ phát hình ảnh/âm thanh, không gây sát thương hay lửa."))));

        // ---- Đọc từ source Mechanics/ProjectileShotMechanic & PotionZoneMechanic ----

        register(new ActionSchema("PROJECTILE_SHOT", Category.DAMAGE, Material.ARROW,
                "Bắn Đạn", "Bắn một hoặc nhiều đạn theo hướng nhìn của người chơi; sát thương áp dụng khi đạn trúng sinh vật.",
                List.of(
                        enumOf("projectile", "SNOWBALL", "Loại đạn", "Loại projectile được bắn ra.",
                                "SNOWBALL", "EGG", "ARROW", "SPECTRAL_ARROW", "WITHER_SKULL", "SMALL_FIREBALL",
                                "FIREBALL", "DRAGON_FIREBALL", "SHULKER_BULLET", "LLAMA_SPIT", "ENDER_PEARL", "TRIDENT")
                                .withIcon(Material.SNOWBALL),
                        expr("damage", "0", "Sát thương", "Sát thương khi đạn trúng, 0 = không đổi sát thương mặc định (hỗ trợ biểu thức).")
                                .withIcon(Material.REDSTONE),
                        expr("amount", "1", "Số lượng", "Số đạn bắn ra mỗi lần kích hoạt (hỗ trợ biểu thức).")
                                .withIcon(Material.ARROW),
                        expr("spread-angle", "10", "Góc lệch (độ)", "Góc lệch ngang giữa hai đạn liên tiếp (hỗ trợ biểu thức).")
                                .withIcon(Material.COMPASS),
                        expr("speed", "1.5", "Tốc độ", "Tốc độ bay của đạn (hỗ trợ biểu thức).")
                                .withIcon(Material.SUGAR),
                        bool("gravity", true, "Trọng lực", "true = đạn bị rơi xuống theo trọng lực."))));

        register(new ActionSchema("POTION_ZONE", Category.SUPPORT, Material.SPLASH_POTION,
                "Vùng Thuốc", "Ném một bình thuốc, khi chạm đất tạo vùng hiệu ứng tồn tại một khoảng thời gian.",
                List.of(
                        target("VICTIM", "VICTIM", "ACTOR"),
                        expr("speed", "0.6", "Tốc độ ném", "Tốc độ ném bình thuốc (hỗ trợ biểu thức).")
                                .withIcon(Material.SUGAR),
                        expr("radius", "3", "Bán kính", "Bán kính vùng hiệu ứng (hỗ trợ biểu thức).")
                                .withIcon(Material.ENDER_PEARL),
                        expr("duration-seconds", "8", "Thời gian vùng (giây)", "Số giây vùng hiệu ứng tồn tại (hỗ trợ biểu thức).")
                                .withIcon(Material.CLOCK),
                        integer("reapplication-delay-ticks", 20, "Chu kỳ áp lại (tick)", "Số tick giữa hai lần áp hiệu ứng lên cùng một thực thể."),
                        FieldDef.of("color", STRING, null, "Màu hạt", "Màu của hạt trong vùng, dạng \"R,G,B\" (vd 255,0,0). Tùy chọn.")
                                .withIcon(Material.RED_DYE),
                        FieldDef.of("particle", PARTICLE, null, "Loại hạt", "Loại hạt của vùng hiệu ứng. Tùy chọn."),
                        FieldDef.of("effects", EFFECT_LIST, null, "Danh sách hiệu ứng", "Các hiệu ứng thuốc áp lên thực thể trong vùng.")
                                .asRequired())));
    }
}

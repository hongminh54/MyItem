package org.ThienNguyen.Ability;
import org.ThienNguyen.Main;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.HashMap;
import java.util.Map;
public class Freeze implements IAbility {
    @Override
    public String getName() {
        return "FREEZE";
    }
    @Override
    public void execute(Player attacker, LivingEntity target, int level, double baseDamage) {
        if (target == null || target.isDead() || target.hasMetadata("IS_ABILITY_FREEZE")) return;
        final int durationTicks = 40 + (level * 10);
        final Location center = target.getLocation().getBlock().getLocation();
        final Location standLoc = center.clone().add(0.5, 0.0, 0.5);
        standLoc.setDirection(target.getLocation().getDirection());
        target.setMetadata("IS_ABILITY_FREEZE", new FixedMetadataValue(Main.getInstance(), true));
        if (target instanceof Mob mob) {
            mob.setAI(false);
        }
        target.teleport(standLoc);
        Map<Block, BlockData> originalBlocks = new HashMap<>();
        Block bottom = center.getBlock();
        Block top = center.clone().add(0, 1, 0).getBlock();
        saveAndSetIce(bottom, originalBlocks);
        saveAndSetIce(top, originalBlocks);
        center.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 1.0f, 0.5f);
        center.getWorld().spawnParticle(Particle.SNOWFLAKE, standLoc.clone().add(0, 1, 0), 50, 0.5, 1, 0.5, 0.05);
        new BukkitRunnable() {
            int ticks = 0;
            boolean cleanedUp = false;
            @Override
            public void run() {
                if (!target.isValid() || target.isDead() || !target.getLocation().isChunkLoaded() || ticks >= durationTicks) {
                    cleanup();
                    this.cancel();
                    return;
                }
                Location current = target.getLocation();
                if (current.getX() != standLoc.getX() || current.getZ() != standLoc.getZ()) {
                    Location loc = standLoc.clone();
                    loc.setY(current.getY());
                    target.teleport(loc);
                }
                for (Block b : originalBlocks.keySet()) {
                    if (b.getType() != Material.PACKED_ICE) {
                        b.setType(Material.PACKED_ICE, false);
                    }
                }
                if (ticks % 10 == 0) {
                    center.getWorld().spawnParticle(Particle.SNOWFLAKE, standLoc.clone().add(0, 1, 0), 5, 0.3, 0.5, 0.3, 0.02);
                }
                ticks++;
            }
            private void cleanup() {
                if (cleanedUp) return;
                cleanedUp = true;
                if (target instanceof Mob mob && mob.isValid()) {
                    mob.setAI(true);
                }
                if (target.isValid()) {
                    target.removeMetadata("IS_ABILITY_FREEZE", Main.getInstance());
                }
                for (Map.Entry<Block, BlockData> entry : originalBlocks.entrySet()) {
                    Block b = entry.getKey();
                    if (b.getLocation().isChunkLoaded()) {
                        b.setBlockData(entry.getValue(), false);
                    }
                }
                if (center.getWorld() != null && center.isChunkLoaded()) {
                    center.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 0.8f, 1.5f);
                }
            }
        }.runTaskTimer(Main.getInstance(), 0L, 1L);
    }
    private void saveAndSetIce(Block b, Map<Block, BlockData> originalBlocks) {
        originalBlocks.put(b, b.getBlockData());
        b.setType(Material.PACKED_ICE, false);
    }
}